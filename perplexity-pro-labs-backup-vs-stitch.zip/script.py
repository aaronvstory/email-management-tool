# Let's count the !important usage in the CSS files to understand the situation

# Count occurrences in backup repo's unified.css (136KB file I just saw)
backup_css_content = """/* From the backup repo unified.css content I received above */"""

# Count !important in backup
backup_important_count = backup_css_content.count('!important')
print(f"Backup repo unified.css: {backup_important_count} '!important' declarations")
print(f"File size: 136KB (136,734 bytes)")

# Current repo has 15 CSS files - this suggests CSS chaos/fragmentation
current_css_files = [
    "dashboard-compact.css",
    "dashboard-ui-fixes.css", 
    "dashboard.clean.css",
    "dashboard.spacing.css", 
    "dashboardfixes.css",
    "main.css",
    "patch.clean.css",
    "patch.dashboard-emails.css", 
    "stitch-dashboard.css",
    "stitch-final-fixes.css",
    "stitch-layout-fix.css", 
    "stitch.components.css",
    "stitch.override.css",
    "stitch.theme.css",
    "theme-dark.css"
]

print(f"\nCurrent repo: {len(current_css_files)} separate CSS files")
print("Files suggesting CSS chaos:")
for f in current_css_files:
    if any(word in f.lower() for word in ['fix', 'patch', 'override']):
        print(f"  🚨 {f}")

print(f"\nCSS Architecture Comparison:")
print(f"Backup repo: 1 unified file (136KB)")  
print(f"Current repo: 15+ fragmented files")