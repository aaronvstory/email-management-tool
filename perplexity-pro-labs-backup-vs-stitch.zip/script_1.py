# Count !important usage in current repo override file
current_override_content = """/* From stitch.override.css above */
/* Override login page red (from patch.clean.css) */
body.login-page .form-control:focus {
  border-color: #bef264 !important;
  box-shadow: 0 0 0 2px rgba(190, 242, 100, 0.2) !important;
}"""  # This is just a small excerpt for counting

# Read the actual file content I received
with open('/tmp/current_override.txt', 'w') as f:
    f.write("""/* Override login page red (from patch.clean.css) */
body.login-page .form-control:focus {
  border-color: #bef264 !important;
  box-shadow: 0 0 0 2px rgba(190, 242, 100, 0.2) !important;
}

body.login-page .btn-login {
  background: #bef264 !important;
  border: 1px solid #bef264 !important;
  color: #18181b !important;
  font-weight: 700 !important;
}

body.login-page .btn-login:hover {
  background: #a3d154 !important;
  border-color: #a3d154 !important;
}

/* Ensure primary color is always lime green */
:root {
  --brand-primary: #bef264;
  --brand-secondary: #a3d154;
  --brand-accent: #bef264;
}

/* Override any Bootstrap button-primary variants */
.btn-primary,
.btn-danger,
button[type="submit"]:not(.btn-secondary):not(.btn-ghost) {
  background: #bef264 !important;
  border-color: #bef264 !important;
  color: #18181b !important;
  font-weight: 600;
}

.btn-primary:hover,
.btn-danger:hover {
  background: #a3d154 !important;
  border-color: #a3d154 !important;
}

/* Fix any border-l-2 or similar borders that might be red */
.border-l-2, .tw-border-l-2,
.border-l-3, .tw-border-l-3,
.border-l-4, .tw-border-l-4 {
  border-left-color: #bef264 !important;
}

/* Active link states should use lime green */
.nav-item-link.active,
a.active,
.active {
  border-left-color: #bef264 !important;
  background: rgba(190, 242, 100, 0.1) !important;
}

/* Any focus rings should be lime green */
*:focus,
*:focus-visible {
  outline-color: #bef264 !important;
  border-color: #bef264 !important;
}

/* Tailwind ring colors */
.tw-ring-primary,
.tw-focus\\:ring-primary:focus {
  --tw-ring-color: #bef264 !important;
}

/* Badges and status indicators */
.badge-danger,
.badge-error,
.bg-danger,
.text-danger {
  background-color: rgba(190, 242, 100, 0.1) !important;
  color: #bef264 !important;
  border-color: rgba(190, 242, 100, 0.2) !important;
}

/* Remove any red from tables, panels, cards */
.table tbody tr:hover,
.panel:hover,
.card:hover {
  border-color: #bef264 !important;
}

/* Status indicators should use yellow/orange for warnings, not red */
.status-indicator.error,
.status-indicator.danger {
  background-color: rgba(245, 158, 11, 0.1);
  color: #f59e0b;
  border-color: rgba(245, 158, 11, 0.2);
}

/* Target buttons with tw- classes that don't have explicit tw-bg-* */
/* This fixes Edit/Delete/Discard buttons across all Stitch templates */
button[class*="tw-"][class*="tw-flex"][class*="tw-items-center"]:not([class*="tw-bg-"]),
button[class*="tw-"][class*="tw-font-medium"]:not([class*="tw-bg-"]) {
  background: transparent !important;
  border: none !important;
  transition: background-color 0.15s ease, color 0.15s ease;
}

/* Hover states for action buttons */
button[class*="tw-"][class*="tw-text-primary"]:hover {
  background: rgba(190, 242, 100, 0.1) !important;
}

button[class*="tw-"][class*="tw-text-red-"]:hover {
  background: rgba(239, 68, 68, 0.1) !important;
}

button[class*="tw-"][class*="tw-text-yellow-"]:hover,
button[class*="tw-"][class*="tw-text-amber-"]:hover {
  background: rgba(245, 158, 11, 0.1) !important;
}

button[class*="tw-"][class*="tw-text-green-"]:hover {
  background: rgba(34, 197, 94, 0.1) !important;
}

/* Ensure primary buttons with bg-primary keep their styling */
button.tw-bg-primary,
button[class*="tw-bg-primary"] {
  background: #bef264 !important;
  color: #18181b !important;
  border: 1px solid #bef264 !important;
}

button.tw-bg-primary:hover,
button[class*="tw-bg-primary"]:hover {
  background: #a3d154 !important;
  border-color: #a3d154 !important;
}

/* Textual links (not buttons) should have subtle gray bg on hover */
a[class*="tw-"]:not([class*="tw-btn"]):not([class*="tw-bg-primary"]):hover,
a[class*="tw-text-"]:not(.tw-bg-primary):not([class*="tw-btn"]):hover {
  background-color: rgba(39, 39, 42, 0.4) !important;
  border-radius: 4px;
  transition: background-color 0.15s ease;
}

/* Links with explicit hover classes should respect them */
a[class*="hover:tw-bg-"]:hover {
  /* Let Tailwind hover classes take precedence */
  background-color: var(--tw-bg-opacity) !important;
}

/* Primary/lime links should have lime tint on hover */
a[class*="tw-text-primary"]:hover,
a[class*="tw-text-[#bef264]"]:hover {
  background-color: rgba(190, 242, 100, 0.1) !important;
  color: #a3d154 !important;
}""")

# Count !important in this file 
with open('/tmp/current_override.txt', 'r') as f:
    current_content = f.read()
    current_important_count = current_content.count('!important')

print(f"Current repo stitch.override.css: {current_important_count} '!important' declarations")
print(f"File size: ~4.8KB")

print("\n" + "="*80)
print("🚨 CRITICAL CSS FINDINGS:")
print("="*80)