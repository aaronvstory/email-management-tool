import plotly.graph_objects as go
import plotly.io as pio

# Data for the radar chart
categories = ["Route Structure", "API Endpoints", "Template System", "Authentication", "Email Processing", "IMAP Integration", "Attachment Support", "Testing Framework", "UI Quality", "Code Maintainability"]
backup_scores = [9, 9, 8, 9, 9, 9, 8, 9, 8, 9]
current_scores = [8, 8, 7, 9, 8, 9, 9, 6, 5, 4]

# Shorten category names to meet 15 character limit
shortened_categories = [
    "Route Struct",    # Route Structure
    "API Endpoints",   # API Endpoints (already under 15)
    "Template Sys",    # Template System
    "Auth",           # Authentication
    "Email Process",   # Email Processing
    "IMAP Integ",     # IMAP Integration
    "Attachment",     # Attachment Support
    "Testing Frame",   # Testing Framework
    "UI Quality",     # UI Quality (already under 15)
    "Code Maintain"   # Code Maintainability
]

# Create radar chart
fig = go.Figure()

# Add backup repo trace
fig.add_trace(go.Scatterpolar(
    r=backup_scores,
    theta=shortened_categories,
    fill='toself',
    fillcolor='rgba(31, 184, 205, 0.2)',
    line=dict(color='#1FB8CD', width=2),
    name='Backup Repo',
    hovertemplate='<b>%{theta}</b><br>Score: %{r}<extra></extra>'
))

# Add current repo trace
fig.add_trace(go.Scatterpolar(
    r=current_scores,
    theta=shortened_categories,
    fill='toself',
    fillcolor='rgba(219, 69, 69, 0.2)',
    line=dict(color='#DB4545', width=2),
    name='Current Repo',
    hovertemplate='<b>%{theta}</b><br>Score: %{r}<extra></extra>'
))

# Update layout
fig.update_layout(
    title='Repo Comparison: Backup vs Current',
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 10],
            tickfont=dict(size=10)
        ),
        angularaxis=dict(
            tickfont=dict(size=11)
        )
    ),
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    ),
    showlegend=True
)

# Save as PNG and SVG
fig.write_image("radar_comparison.png")
fig.write_image("radar_comparison.svg", format="svg")

fig.show()