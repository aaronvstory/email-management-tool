# Create a comprehensive comparison analysis of the repositories
import pandas as pd

print("EMAIL MANAGEMENT TOOL REPOSITORY ANALYSIS")
print("=" * 80)

# CSS Architecture Analysis
print("\n🎨 CSS ARCHITECTURE COMPARISON:")
print("-" * 40)

css_comparison = {
    "Aspect": [
        "Files Count",
        "Architecture", 
        "!important Usage",
        "Main Issues",
        "Overall State"
    ],
    "Backup Repo (email-management-tool-2-main)": [
        "1 unified file (136KB)",
        "Consolidated, organized",
        "0 declarations",
        "None identified",
        "✅ Clean, production-ready"
    ],
    "Current Repo (feat/styleguide-refresh)": [
        "15+ fragmented files",
        "Chaotic, patch-heavy",
        "38+ declarations (in just 1 file!)",
        "Override hell, lime green theme forced",
        "🚨 Critical CSS explosion"
    ]
}

css_df = pd.DataFrame(css_comparison)
print(css_df.to_string(index=False))

print("\n🚨 CRITICAL CSS FILES IN CURRENT REPO:")
critical_files = [
    "dashboard-ui-fixes.css",
    "dashboardfixes.css", 
    "patch.clean.css",
    "patch.dashboard-emails.css",
    "stitch-final-fixes.css",
    "stitch-layout-fix.css",
    "stitch.override.css (38 !important)"
]

for file in critical_files:
    print(f"  • {file}")

print("\n" + "="*80)
print("📊 BACKEND FUNCTIONALITY ANALYSIS:")
print("-" * 40)

# Route Analysis
routes_backup = [
    "accounts.py (44KB)",
    "auth.py (2.4KB)", 
    "compose.py (7KB)",
    "dashboard.py (4.3KB)",
    "diagnostics.py (13.6KB)",
    "emails.py (26.6KB)",
    "inbox.py (2KB)",
    "interception.py (116KB) - CORE",
    "moderation.py (7.2KB)",
    "stats.py (5.9KB)",
    "styleguide.py (0.5KB)",
    "system.py (8.2KB)",
    "watchers.py (9.5KB)"
]

routes_current = [
    "accounts.py (45KB) +1KB",
    "auth.py (2.4KB) same",
    "compose.py (7.5KB) +0.5KB", 
    "dashboard.py (4.3KB) same",
    "diagnostics.py (13.6KB) same",
    "emails.py (27.9KB) +1.3KB",
    "inbox.py (2KB) same",
    "interception.py (116.8KB) +0.2KB",
    "moderation.py (9KB) +1.8KB",
    "stats.py (5.9KB) same",
    "styleguide.py (0.7KB) +0.2KB",
    "system.py (8.2KB) same", 
    "watchers.py (9.7KB) +0.2KB"
]

print("BACKUP REPO ROUTES:")
for route in routes_backup[:6]:
    print(f"  {route}")
print("  ... (13 total routes)")

print("\nCURRENT REPO ROUTES:")
for route in routes_current[:6]:
    print(f"  {route}")
print("  ... (13 total routes)")

print("\n📁 TEMPLATES ANALYSIS:")
print("-" * 30)

templates_comparison = {
    "Template": [
        "dashboard_unified.html",
        "emails_unified.html", 
        "base.html",
        "Templates Structure"
    ],
    "Backup": [
        "34.7KB - cleaner?",
        "51.2KB - working features",
        "13.5KB",
        "Standard structure"
    ],
    "Current": [
        "53.8KB - bloated?",
        "59.9KB - more features?", 
        "19.4KB - extended",
        "+ stitch/ + styleguide/ folders"
    ]
}

templates_df = pd.DataFrame(templates_comparison)
print(templates_df.to_string(index=False))